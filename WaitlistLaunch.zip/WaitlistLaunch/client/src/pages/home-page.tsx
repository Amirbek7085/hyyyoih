import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";
import { Coins, Gamepad2, Dices, Shield, CreditCard } from "lucide-react";

export default function HomePage() {
  const { user, logoutMutation } = useAuth();
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div className="flex items-center gap-4">
            <h1 className="text-2xl font-bold">Welcome, {user?.username}!</h1>
            <div className="flex items-center gap-2 bg-primary/10 px-3 py-1 rounded-full">
              <Coins className="h-4 w-4" />
              <span>{user?.coins || 0} coins</span>
            </div>
          </div>
          <Button 
            variant="destructive"
            onClick={() => logoutMutation.mutate()}
            disabled={logoutMutation.isPending}
          >
            Logout
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Gamepad2 className="h-5 w-5" />
                Mafia O'yini
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Button 
                className="w-full" 
                onClick={() => setLocation("/game")}
              >
                O'yinga kirish
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Dices className="h-5 w-5" />
                Kazino
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Button 
                className="w-full"
                onClick={() => setLocation("/casino")}
              >
                Kazinoga kirish
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="h-5 w-5" />
                Coin sotib olish
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Button 
                className="w-full"
                onClick={() => setLocation("/payment")}
              >
                Sotib olish
              </Button>
            </CardContent>
          </Card>

          {user?.isAdmin && (
            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5" />
                  Admin Panel
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Button 
                  className="w-full"
                  variant="outline"
                  onClick={() => setLocation("/admin")}
                >
                  Open Admin Panel
                </Button>
              </CardContent>
            </Card>
          )}

          <Card className="md:col-span-2">
            <CardHeader>
              <CardTitle>O'yin qoidalari</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="list-disc pl-4 space-y-2">
                <li>Each game has multiple roles: Mafia, Doctor, Detective, and Civilians</li>
                <li>During the night phase, special roles perform their actions</li>
                <li>During the day phase, all players discuss and vote</li>
                <li>Win coins by surviving and helping your team win</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}