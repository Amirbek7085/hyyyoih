import { useEffect } from "react";
import { useGame } from "@/hooks/use-game";
import { useAuth } from "@/hooks/use-auth";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import Chat from "@/components/game/chat";
import PlayerList from "@/components/game/player-list";
import { Moon, Sun } from "lucide-react";
import { useLocation } from "wouter";

export default function GamePage() {
  const { connect, disconnect, gameState, isConnecting, error } = useGame();
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    connect();
    return () => disconnect();
  }, []);

  if (isConnecting || !gameState) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="p-6">
          {error ? (
            <div className="text-center">
              <p className="text-destructive mb-4">{error}</p>
              <Button 
                variant="outline" 
                onClick={() => setLocation("/")}
              >
                Return Home
              </Button>
            </div>
          ) : (
            <div className="flex items-center gap-3">
              <Loader2 className="h-5 w-5 animate-spin" />
              <p>Connecting to game...</p>
            </div>
          )}
        </Card>
      </div>
    );
  }

  const currentPlayer = gameState.players.find(p => p.id === user?.id);
  const isGameActive = gameState.phase !== "waiting" && gameState.phase !== "ended";
  const canVote = gameState.phase === "voting" && currentPlayer?.isAlive;
  const isNight = gameState.phase === "night";

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 space-y-4">
          <Card className="p-4">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                {gameState.phase === "day" || gameState.phase === "voting" ? (
                  <Sun className="h-5 w-5 text-yellow-500" />
                ) : (
                  <Moon className="h-5 w-5 text-blue-500" />
                )}
                <span className="font-bold capitalize">
                  {gameState.phase} {isGameActive && `(Round ${gameState.round})`}
                </span>
              </div>
              {currentPlayer?.role && (
                <span className="bg-primary/10 px-3 py-1 rounded-full capitalize">
                  Role: {currentPlayer.role}
                </span>
              )}
            </div>

            {gameState.winners ? (
              <div className="text-center p-4">
                <h2 className="text-xl font-bold mb-2">Game Over!</h2>
                <p className="text-muted-foreground">
                  Winners: {gameState.winners.join(", ")}
                </p>
              </div>
            ) : (
              <PlayerList 
                players={gameState.players} 
                currentPlayer={currentPlayer}
                canVote={canVote}
                isNight={isNight}
              />
            )}
          </Card>

          <Chat messages={gameState.messages} />
        </div>

        <Card className="p-4">
          <h2 className="text-lg font-bold mb-4">Game Controls</h2>
          <div className="space-y-2">
            {gameState.phase === "waiting" && (
              <div className="text-center p-4">
                <p className="text-muted-foreground mb-4">
                  Waiting for players...
                  ({gameState.players.length} / 7 minimum)
                </p>
              </div>
            )}

            <Button 
              className="w-full" 
              variant="destructive"
              onClick={() => {
                disconnect();
                setLocation("/");
              }}
            >
              Leave Game
            </Button>
          </div>

          {currentPlayer?.role && (
            <div className="mt-4 p-4 border rounded-lg">
              <h3 className="font-semibold mb-2">Role Instructions</h3>
              <p className="text-sm text-muted-foreground">
                {getRoleInstructions(currentPlayer.role)}
              </p>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}

function getRoleInstructions(role: string): string {
  switch (role) {
    case "mafia":
      return "At night, work with other mafia members to eliminate civilians. Stay hidden during the day.";
    case "don":
      return "Lead the mafia team. You can see other mafia members and coordinate night actions.";
    case "doctor":
      return "Each night, choose one player to protect from being eliminated.";
    case "detective":
      return "Each night, investigate one player to learn if they are mafia or civilian.";
    case "sniper":
      return "Once per game, eliminate a player during the night phase.";
    case "spy":
      return "Each night, gather intelligence about player roles.";
    case "civilian":
      return "Work with other civilians to identify and eliminate mafia members during day discussions.";
    default:
      return "Participate in discussions and voting to help your team win.";
  }
}