import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";
import { Coins } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import SlotMachine from "@/components/casino/slot-machine";
import Roulette from "@/components/casino/roulette";

export default function CasinoPage() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-6xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-2xl font-bold">Kazino</h1>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 bg-primary/10 px-3 py-1 rounded-full">
              <Coins className="h-4 w-4" />
              <span>{user?.coins || 0} coins</span>
            </div>
            <Button 
              variant="outline"
              onClick={() => setLocation("/")}
            >
              Orqaga
            </Button>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>O'yinlar</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="slots" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="slots">Slot Mashina</TabsTrigger>
                <TabsTrigger value="roulette">Ruletka</TabsTrigger>
              </TabsList>

              <TabsContent value="slots" className="mt-4">
                <SlotMachine />
              </TabsContent>

              <TabsContent value="roulette" className="mt-4">
                <Roulette />
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        <Card className="mt-4">
          <CardHeader>
            <CardTitle>Tez orada</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="list-disc pl-4 space-y-2 text-muted-foreground">
              <li>Poker</li>
              <li>Blackjack</li>
              <li>Sport tikish</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}