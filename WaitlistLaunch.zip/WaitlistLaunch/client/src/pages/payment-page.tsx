import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";
import { Coins, CreditCard } from "lucide-react";
import { loadStripe } from "@stripe/stripe-js";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY);

const COIN_PACKAGES = [
  { coins: 100, price: 10.00, bonus: 0 },
  { coins: 500, price: 45.00, bonus: 50 },
  { coins: 1000, price: 80.00, bonus: 200 },
];

export default function PaymentPage() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [selectedPackage, setSelectedPackage] = useState<number | null>(null);

  const paymentMutation = useMutation({
    mutationFn: async (coins: number) => {
      const response = await apiRequest("POST", "/api/payment/create-intent", { coins });
      const { clientSecret } = await response.json();

      const stripe = await stripePromise;
      if (!stripe) throw new Error("Stripe not loaded");

      const result = await stripe.confirmCardPayment(clientSecret, {
        payment_method: {
          card: {
            // TODO: Add card element
          },
          billing_details: {
            name: user?.username,
          },
        },
      });

      if (result.error) {
        throw result.error;
      }

      return result.paymentIntent;
    },
    onSuccess: () => {
      toast({
        title: "To'lov muvaffaqiyatli amalga oshirildi",
        description: "Coinlar hisobingizga qo'shildi",
      });
      setLocation("/");
    },
    onError: (error: Error) => {
      toast({
        title: "To'lov amalga oshmadi",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-2xl font-bold">Coin sotib olish</h1>
          <div className="flex items-center gap-2 bg-primary/10 px-3 py-1 rounded-full">
            <Coins className="h-4 w-4" />
            <span>{user?.coins || 0} coins</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {COIN_PACKAGES.map((pkg, index) => (
            <Card 
              key={index}
              className={selectedPackage === index ? "ring-2 ring-primary" : ""}
            >
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Coins className="h-5 w-5" />
                  {pkg.coins} Coins
                  {pkg.bonus > 0 && (
                    <span className="text-sm text-green-500">
                      +{pkg.bonus} bonus
                    </span>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold mb-4">
                  ${pkg.price.toFixed(2)}
                </div>
                <Button
                  className="w-full"
                  variant={selectedPackage === index ? "default" : "outline"}
                  onClick={() => setSelectedPackage(index)}
                >
                  Tanlash
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        <Card className="mt-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CreditCard className="h-5 w-5" />
              To'lov ma'lumotlari
            </CardTitle>
          </CardHeader>
          <CardContent>
            {/* TODO: Add Stripe Elements */}
            <Button
              className="w-full"
              disabled={selectedPackage === null || paymentMutation.isPending}
              onClick={() => {
                if (selectedPackage !== null) {
                  paymentMutation.mutate(COIN_PACKAGES[selectedPackage].coins);
                }
              }}
            >
              {paymentMutation.isPending ? "To'lov amalga oshirilmoqda..." : "To'lash"}
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
