import { createContext, ReactNode, useContext, useEffect, useState } from "react";
import { GameState } from "@shared/schema";
import { useAuth } from "./use-auth";
import { useToast } from "./use-toast";

interface GameContextType {
  connect: () => void;
  disconnect: () => void;
  sendMessage: (content: string) => void;
  gameState: GameState | null;
  isConnecting: boolean;
  isConnected: boolean;
  error: string | null;
}

const GameContext = createContext<GameContextType | null>(null);

export function GameProvider({ children }: { children: ReactNode }) {
  const [socket, setSocket] = useState<WebSocket | null>(null);
  const [gameState, setGameState] = useState<GameState | null>(null);
  const [isConnecting, setIsConnecting] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();
  const { toast } = useToast();

  const connect = () => {
    if (socket || !user) return;

    try {
      setIsConnecting(true);
      setError(null);

      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      const wsUrl = `${protocol}//${window.location.host}/game-ws`;
      console.log("Connecting to WebSocket:", wsUrl);

      const ws = new WebSocket(wsUrl);

      ws.onopen = () => {
        console.log("WebSocket connection opened");
        setIsConnected(true);
        setIsConnecting(false);

        // Send join message immediately after connection
        ws.send(JSON.stringify({
          type: "join",
          username: user.username
        }));
      };

      ws.onmessage = (event) => {
        try {
          console.log("Received WebSocket message:", event.data);
          const data = JSON.parse(event.data);
          if (data.type === "error") {
            console.error("Server error:", data.message);
            toast({
              title: "Game Error",
              description: data.message,
              variant: "destructive",
            });
            return;
          }
          setGameState(data);
        } catch (err) {
          console.error("Failed to parse game state:", err);
          setError("Failed to parse game state");
        }
      };

      ws.onclose = (event) => {
        console.log("WebSocket connection closed:", event.code, event.reason);
        setIsConnected(false);
        setSocket(null);
        setIsConnecting(false);

        if (event.code === 1008) {
          // Authentication error
          toast({
            title: "Authentication Error",
            description: "Please log in again",
            variant: "destructive",
          });
          return;
        }

        // Only show disconnect message if it wasn't intentional
        if (event.code !== 1000) {
          toast({
            title: "Disconnected",
            description: event.reason || "Lost connection to the game server",
            variant: "destructive",
          });

          // Try to reconnect after 5 seconds
          setTimeout(() => {
            if (!socket) {
              connect();
            }
          }, 5000);
        }
      };

      ws.onerror = (event) => {
        console.error("WebSocket error:", event);
        setError("Failed to connect to game server");
        setIsConnecting(false);
        toast({
          title: "Connection Error",
          description: "Failed to connect to game server",
          variant: "destructive",
        });
      };

      setSocket(ws);
    } catch (err) {
      console.error("Failed to create WebSocket:", err);
      setError("Failed to create WebSocket connection");
      setIsConnecting(false);
    }
  };

  const disconnect = () => {
    if (socket) {
      socket.close(1000, "User disconnected");
      setSocket(null);
      setIsConnected(false);
      setGameState(null);
    }
  };

  const sendMessage = (content: string) => {
    if (socket && socket.readyState === WebSocket.OPEN && user) {
      socket.send(JSON.stringify({
        type: "chat",
        content,
        username: user.username
      }));
    }
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (socket) {
        socket.close(1000, "Component unmounted");
      }
    };
  }, []);

  return (
    <GameContext.Provider
      value={{
        connect,
        disconnect,
        sendMessage,
        gameState,
        isConnecting,
        isConnected,
        error
      }}
    >
      {children}
    </GameContext.Provider>
  );
}

export function useGame() {
  const context = useContext(GameContext);
  if (!context) {
    throw new Error("useGame must be used within a GameProvider");
  }
  return context;
}