import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";

const BET_AMOUNT = 10;
const PAYOUT_MULTIPLIER = {
  number: 35, // Betting on exact number
  color: 2,   // Red or black
  range: 2,   // 1-18 or 19-36
  dozen: 3,   // 1-12, 13-24, 25-36
  column: 3,  // First, second, or third column
};

type BetType = "number" | "color" | "range" | "dozen" | "column";
interface Bet {
  type: BetType;
  value: string | number;
  amount: number;
}

const NUMBERS = Array.from({ length: 37 }, (_, i) => i); // 0-36
const RED_NUMBERS = [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36];
const BLACK_NUMBERS = NUMBERS.filter(n => n !== 0 && !RED_NUMBERS.includes(n));

export default function Roulette() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedBets, setSelectedBets] = useState<Bet[]>([]);
  const [spinning, setSpinning] = useState(false);
  const [result, setResult] = useState<number | null>(null);

  const spinMutation = useMutation({
    mutationFn: async () => {
      // Deduct total bet amount
      const totalBet = selectedBets.reduce((sum, bet) => sum + bet.amount, 0);
      await apiRequest("POST", "/api/coins/transaction", { amount: -totalBet });

      // Simulate spin
      const winningNumber = Math.floor(Math.random() * 37); // 0-36

      // Calculate winnings
      let totalWin = 0;
      selectedBets.forEach(bet => {
        let won = false;
        switch (bet.type) {
          case "number":
            won = winningNumber === bet.value;
            if (won) totalWin += bet.amount * PAYOUT_MULTIPLIER.number;
            break;
          case "color":
            if (winningNumber === 0) break;
            won = bet.value === "red" ?
              RED_NUMBERS.includes(winningNumber) :
              BLACK_NUMBERS.includes(winningNumber);
            if (won) totalWin += bet.amount * PAYOUT_MULTIPLIER.color;
            break;
          case "range":
            if (winningNumber === 0) break;
            won = bet.value === "1-18" ?
              winningNumber <= 18 :
              winningNumber > 18;
            if (won) totalWin += bet.amount * PAYOUT_MULTIPLIER.range;
            break;
          case "dozen":
            if (winningNumber === 0) break;
            const dozen = Math.floor((winningNumber - 1) / 12);
            won = bet.value === `${dozen * 12 + 1}-${(dozen + 1) * 12}`;
            if (won) totalWin += bet.amount * PAYOUT_MULTIPLIER.dozen;
            break;
          case "column":
            if (winningNumber === 0) break;
            const column = (winningNumber - 1) % 3;
            won = Number(bet.value) === column;
            if (won) totalWin += bet.amount * PAYOUT_MULTIPLIER.column;
            break;
        }
      });

      if (totalWin > 0) {
        await apiRequest("POST", "/api/coins/transaction", { amount: totalWin });
      }

      return { winningNumber, totalWin };
    },
    onMutate: () => {
      setSpinning(true);
      // Animate spinning
      const interval = setInterval(() => {
        setResult(Math.floor(Math.random() * 37));
      }, 100);

      // Stop animation after 2 seconds
      setTimeout(() => clearInterval(interval), 2000);
    },
    onSuccess: async ({ winningNumber, totalWin }) => {
      // Show final result after animation
      setTimeout(() => {
        setResult(winningNumber);
        setSpinning(false);

        if (totalWin > 0) {
          toast({
            title: "Tabriklaymiz! 🎉",
            description: `Siz ${totalWin} coin yutdingiz!`,
          });
        }

        // Clear bets
        setSelectedBets([]);
      }, 2000);

      // Refresh user data to update coins
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
    },
    onError: (error: Error) => {
      setSpinning(false);
      toast({
        title: "Xatolik yuz berdi",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const addBet = (type: BetType, value: string | number) => {
    if (!user || user.coins < BET_AMOUNT) {
      toast({
        title: "Mablag' yetarli emas",
        description: `O'yin uchun kamida ${BET_AMOUNT} coin kerak`,
        variant: "destructive",
      });
      return;
    }

    setSelectedBets(prev => [...prev, { type, value, amount: BET_AMOUNT }]);
  };

  return (
    <div className="flex flex-col items-center gap-6">
      {/* Roulette wheel visualization */}
      <div className="relative w-64 h-64 rounded-full border-4 border-primary flex items-center justify-center bg-background/50">
        <div className="absolute inset-0 rounded-full overflow-hidden">
          {NUMBERS.map((number, i) => (
            <div
              key={number}
              className={cn(
                "absolute w-8 h-32 -mt-16 origin-bottom transform transition-transform duration-200",
                {
                  "bg-red-600": RED_NUMBERS.includes(number),
                  "bg-black": BLACK_NUMBERS.includes(number),
                  "bg-green-600": number === 0
                }
              )}
              style={{
                transform: `rotate(${(i * 360) / 37}deg)`
              }}
            >
              <span className="absolute top-0 left-1/2 -translate-x-1/2 text-white text-sm">
                {number}
              </span>
            </div>
          ))}
        </div>
        {result !== null && (
          <div className="text-4xl font-bold animate-bounce">
            {result}
          </div>
        )}
      </div>

      {/* Betting options */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
        <Button
          onClick={() => addBet("color", "red")}
          className="bg-red-600 hover:bg-red-700"
          disabled={spinning}
        >
          Qizil
        </Button>
        <Button
          onClick={() => addBet("color", "black")}
          className="bg-black hover:bg-gray-900"
          disabled={spinning}
        >
          Qora
        </Button>
        <Button
          onClick={() => addBet("range", "1-18")}
          disabled={spinning}
        >
          1-18
        </Button>
        <Button
          onClick={() => addBet("range", "19-36")}
          disabled={spinning}
        >
          19-36
        </Button>
      </div>

      {/* Number grid */}
      <div className="grid grid-cols-3 gap-1">
        {Array.from({ length: 12 }, (_, i) => (
          <div key={i} className="flex flex-col gap-1">
            {Array.from({ length: 3 }, (_, j) => {
              const number = i * 3 + j + 1;
              return (
                <Button
                  key={number}
                  onClick={() => addBet("number", number)}
                  className={cn("w-12 h-12", {
                    "bg-red-600 hover:bg-red-700": RED_NUMBERS.includes(number),
                    "bg-black hover:bg-gray-900": BLACK_NUMBERS.includes(number)
                  })}
                  disabled={spinning}
                >
                  {number}
                </Button>
              );
            })}
          </div>
        ))}
        <Button
          onClick={() => addBet("number", 0)}
          className="w-12 h-12 bg-green-600 hover:bg-green-700 col-span-3"
          disabled={spinning}
        >
          0
        </Button>
      </div>

      {/* Selected bets */}
      {selectedBets.length > 0 && (
        <div className="space-y-2">
          <h3 className="font-semibold">Tanlangan stavkalar:</h3>
          <div className="flex flex-wrap gap-2">
            {selectedBets.map((bet, i) => (
              <Badge key={i} variant="secondary">
                {bet.value} ({bet.amount} coin)
              </Badge>
            ))}
          </div>
        </div>
      )}

      {/* Spin button */}
      <Button
        onClick={() => spinMutation.mutate()}
        disabled={spinning || selectedBets.length === 0}
        className="w-32"
      >
        {spinning ? (
          <Loader2 className="h-4 w-4 animate-spin" />
        ) : (
          "Aylantirish"
        )}
      </Button>
    </div>
  );
}