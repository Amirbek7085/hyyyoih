import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";

const SYMBOLS = ["🍒", "🍊", "🍋", "7️⃣", "💎"];
const BET_AMOUNT = 10;
const WIN_PROBABILITY = 0.15; // 15% chance to win

export default function SlotMachine() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [reels, setReels] = useState<string[]>(["❓", "❓", "❓"]);
  const [isSpinning, setIsSpinning] = useState(false);

  const spinMutation = useMutation({
    mutationFn: async () => {
      // Deduct coins first
      await apiRequest("POST", "/api/coins/transaction", { amount: -BET_AMOUNT });
      
      // Simulate spin with win probability
      const isWin = Math.random() < WIN_PROBABILITY;
      
      if (isWin) {
        // If win, all reels show same symbol
        const winningSymbol = SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)];
        const winAmount = BET_AMOUNT * 3;
        await apiRequest("POST", "/api/coins/transaction", { amount: winAmount });
        return [winningSymbol, winningSymbol, winningSymbol];
      } else {
        // If lose, show random different symbols
        return Array.from({ length: 3 }, () => 
          SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)]
        );
      }
    },
    onMutate: () => {
      setIsSpinning(true);
      // Animate spinning
      const interval = setInterval(() => {
        setReels(reels => 
          reels.map(() => SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)])
        );
      }, 100);
      
      // Stop animation after 2 seconds
      setTimeout(() => clearInterval(interval), 2000);
    },
    onSuccess: async (newReels) => {
      // Show final result after animation
      setTimeout(() => {
        setReels(newReels);
        setIsSpinning(false);
        
        // Check if won
        const isWin = newReels.every(symbol => symbol === newReels[0]);
        if (isWin) {
          toast({
            title: "Tabriklaymiz! 🎉",
            description: `Siz ${BET_AMOUNT * 3} coin yutdingiz!`,
          });
        }
      }, 2000);
      
      // Refresh user data to update coins
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
    },
    onError: (error: Error) => {
      setIsSpinning(false);
      toast({
        title: "Xatolik yuz berdi",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSpin = () => {
    if (!user || user.coins < BET_AMOUNT) {
      toast({
        title: "Mablag' yetarli emas",
        description: `O'yin uchun kamida ${BET_AMOUNT} coin kerak`,
        variant: "destructive",
      });
      return;
    }
    spinMutation.mutate();
  };

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="flex gap-2 text-4xl p-4 bg-background/50 rounded-lg">
        {reels.map((symbol, i) => (
          <div 
            key={i}
            className="w-16 h-16 flex items-center justify-center border rounded-lg"
          >
            {symbol}
          </div>
        ))}
      </div>
      
      <div className="space-y-2 text-center">
        <p className="text-sm text-muted-foreground">
          Har bir o'yin {BET_AMOUNT} coin turadi
        </p>
        <Button
          onClick={handleSpin}
          disabled={isSpinning || !user || user.coins < BET_AMOUNT}
          className="w-32"
        >
          {isSpinning ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            "O'ynash"
          )}
        </Button>
      </div>
    </div>
  );
}
