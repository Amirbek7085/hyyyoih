import { GameState } from "@shared/schema";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skull, Shield, Target, Search } from "lucide-react";
import { useGame } from "@/hooks/use-game";

interface PlayerListProps {
  players: GameState["players"];
  currentPlayer?: GameState["players"][0];
  canVote: boolean;
  isNight: boolean;
}

export default function PlayerList({ 
  players, 
  currentPlayer, 
  canVote,
  isNight 
}: PlayerListProps) {
  const { sendMessage } = useGame();

  const handleAction = (targetId: number, actionType: string) => {
    sendMessage(JSON.stringify({
      type: "action",
      actionType,
      target: targetId
    }));
  };

  const handleVote = (targetId: number) => {
    sendMessage(JSON.stringify({
      type: "vote",
      target: targetId
    }));
  };

  const canTargetPlayer = (targetPlayer: GameState["players"][0]) => {
    if (!currentPlayer?.role || !targetPlayer.isAlive) return false;
    if (targetPlayer.id === currentPlayer.id) return false;

    return true;
  };

  const getNightActionButton = (targetPlayer: GameState["players"][0]) => {
    if (!currentPlayer?.role || !isNight || !canTargetPlayer(targetPlayer)) return null;

    switch (currentPlayer.role) {
      case "mafia":
      case "don":
        return (
          <Button
            size="sm"
            variant="destructive"
            onClick={() => handleAction(targetPlayer.id, "kill")}
          >
            <Target className="h-4 w-4 mr-1" />
            Kill
          </Button>
        );
      case "doctor":
        return (
          <Button
            size="sm"
            variant="secondary"
            onClick={() => handleAction(targetPlayer.id, "heal")}
          >
            <Shield className="h-4 w-4 mr-1" />
            Heal
          </Button>
        );
      case "detective":
        return (
          <Button
            size="sm"
            variant="secondary"
            onClick={() => handleAction(targetPlayer.id, "investigate")}
          >
            <Search className="h-4 w-4 mr-1" />
            Investigate
          </Button>
        );
      default:
        return null;
    }
  };

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
      {players.map((player) => (
        <div
          key={player.id}
          className={`flex flex-col items-center p-2 rounded-lg border ${
            !player.isAlive ? "opacity-50" : ""
          }`}
        >
          <Avatar className="h-12 w-12">
            <AvatarFallback>
              {player.username.slice(0, 2).toUpperCase()}
            </AvatarFallback>
          </Avatar>

          <span className="mt-2 font-medium text-sm">{player.username}</span>

          {!player.isAlive && (
            <Badge variant="destructive" className="mt-1">
              <Skull className="h-3 w-3 mr-1" />
              Dead
            </Badge>
          )}

          {player.isAlive && canVote && player.id !== currentPlayer?.id && (
            <Button
              size="sm"
              variant="outline"
              className="mt-2"
              onClick={() => handleVote(player.id)}
            >
              Vote
            </Button>
          )}

          {isNight && getNightActionButton(player)}
        </div>
      ))}
    </div>
  );
}