import { pgTable, text, serial, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  coins: integer("coins").notNull().default(0),
  isAdmin: boolean("is_admin").notNull().default(false)
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type GameRole = 
  | "mafia" 
  | "don"
  | "doctor" 
  | "detective" 
  | "civilian"
  | "sniper"
  | "spy"
  | "hacker"
  | "guard"
  | "lawyer"
  | "avenger"
  | "psychologist"
  | "terrorist"
  | "businessman"
  | "wizard"
  | "criminal";

export type GamePhase = "waiting" | "night" | "day" | "voting" | "ended";

export type GameAction = {
  type: "kill" | "heal" | "investigate" | "protect" | "vote";
  fromPlayer: number;
  toPlayer: number;
  timestamp: number;
};

export type GameState = {
  id: string;
  players: {
    id: number;
    username: string;
    role?: GameRole;
    isAlive: boolean;
    lastAction?: GameAction;
  }[];
  phase: GamePhase;
  round: number;
  messages: {
    id: string;
    username: string;
    content: string;
    timestamp: number;
    isSystem?: boolean;
  }[];
  actions: GameAction[];
  winners?: GameRole[];
};