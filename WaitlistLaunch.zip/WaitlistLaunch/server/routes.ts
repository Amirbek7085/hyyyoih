import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { GameManager } from "./game";
import { storage } from "./storage";
import { createPaymentIntent, handleStripeWebhook } from "./stripe";
import Stripe from "stripe";

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);

  const httpServer = createServer(app);
  const gameManager = new GameManager();
  gameManager.setupWebSocket(httpServer);

  // Payment routes
  app.post("/api/payment/create-intent", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }

    try {
      const { coins } = req.body;
      const clientSecret = await createPaymentIntent(req.user.id, coins);
      res.json({ clientSecret });
    } catch (err) {
      res.status(400).json({ error: (err as Error).message });
    }
  });

  app.post("/api/payment/webhook", async (req, res) => {
    const sig = req.headers["stripe-signature"];
    if (!sig) {
      return res.sendStatus(400);
    }

    try {
      const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
        apiVersion: "2023-10-16",
      });
      const event = stripe.webhooks.constructEvent(
        req.body,
        sig,
        process.env.STRIPE_WEBHOOK_SECRET || ""
      );
      await handleStripeWebhook(event);
      res.sendStatus(200);
    } catch (err) {
      console.error("Webhook error:", err);
      res.status(400).json({ error: (err as Error).message });
    }
  });

  // Admin routes
  app.get("/api/admin/stats", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.sendStatus(401);
    }

    const stats = {
      activePlayers: gameManager.getActivePlayers(),
      totalCoins: await storage.getTotalCoins(),
      activeGames: gameManager.getActiveGames()
    };

    res.json(stats);
  });

  app.post("/api/admin/block-user", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.sendStatus(401);
    }

    const { userId, reason } = req.body;
    await storage.blockUser(userId, reason);
    res.json({ success: true });
  });

  // Game routes
  app.post("/api/game/join", (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    res.json({ success: true });
  });

  app.post("/api/game/leave", (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    res.json({ success: true });
  });

  app.post("/api/coins/transaction", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const { amount } = req.body;
      const user = await storage.updateUserCoins(req.user.id, amount);
      res.json(user);
    } catch (err) {
      res.status(400).json({ error: "Transaction failed" });
    }
  });

  return httpServer;
}