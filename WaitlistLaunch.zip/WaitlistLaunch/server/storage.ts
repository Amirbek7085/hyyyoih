import { User, InsertUser } from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;  
  createUser(user: InsertUser): Promise<User>;
  updateUserCoins(userId: number, amount: number): Promise<User>;
  getTotalCoins(): Promise<number>;
  blockUser(userId: number, reason: string): Promise<void>;
  sessionStore: session.Store;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private currentId: number;
  private blockedUsers: Map<number, string>;
  sessionStore: session.Store;

  constructor() {
    this.users = new Map();
    this.currentId = 1;
    this.blockedUsers = new Map();
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = { ...insertUser, id, coins: 0, isAdmin: false };
    this.users.set(id, user);
    return user;
  }

  async updateUserCoins(userId: number, amount: number): Promise<User> {
    const user = await this.getUser(userId);
    if (!user) throw new Error("User not found");

    if (this.blockedUsers.has(userId)) {
      throw new Error("User is blocked");
    }

    const updatedUser = {
      ...user,
      coins: Math.max(0, user.coins + amount) // Prevent negative coins
    };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  async getTotalCoins(): Promise<number> {
    return Array.from(this.users.values()).reduce((sum, user) => sum + user.coins, 0);
  }

  async blockUser(userId: number, reason: string): Promise<void> {
    if (!this.users.has(userId)) {
      throw new Error("User not found");
    }
    this.blockedUsers.set(userId, reason);
  }
}

export const storage = new MemStorage();