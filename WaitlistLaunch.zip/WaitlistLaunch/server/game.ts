import { WebSocketServer, WebSocket } from "ws";
import { Server } from "http";
import { GameState, GameRole, GamePhase, GameAction } from "@shared/schema";
import { randomUUID } from "crypto";
import { parse } from "cookie";
import { storage } from "./storage";
import { sessionMiddleware } from "./index";

// Wrap session middleware in a Promise
function parseSession(req: any): Promise<void> {
  return new Promise((resolve, reject) => {
    sessionMiddleware(req, {} as any, (err: any) => {
      if (err) reject(err);
      else resolve();
    });
  });
}

interface GameMessage {
  type: "chat" | "vote" | "action" | "join" | "ready";
  content?: string;
  username: string;
  target?: number;
  actionType?: GameAction["type"];
}

export class GameManager {
  private games: Map<string, GameState>;
  private playerSockets: Map<number, WebSocket>;
  private connectedClients: Set<WebSocket>;
  private readonly NIGHT_DURATION = 30000; // 30 seconds for night phase
  private readonly DAY_DURATION = 60000; // 60 seconds for day phase
  private readonly VOTING_DURATION = 30000; // 30 seconds for voting
  private readonly MIN_PLAYERS = 7;
  private readonly GAME_REWARDS = {
    WIN: 100, // Coins for winning
    SURVIVE: 50, // Coins for surviving
    PARTICIPATION: 20 // Coins for participating
  };

  constructor() {
    this.games = new Map();
    this.playerSockets = new Map();
    this.connectedClients = new Set();

    const defaultGame: GameState = {
      id: "default",
      players: [],
      phase: "waiting",
      round: 0,
      messages: [],
      actions: []
    };
    this.games.set("default", defaultGame);
  }

  public getActivePlayers(): number {
    return this.connectedClients.size;
  }

  public getActiveGames(): number {
    let activeGames = 0;
    this.games.forEach(game => {
      if (game.phase !== "waiting" && game.phase !== "ended") {
        activeGames++;
      }
    });
    return activeGames;
  }

  setupWebSocket(server: Server) {
    const wss = new WebSocketServer({ 
      server, 
      path: "/game-ws",
      clientTracking: true,
      verifyClient: async (info, cb) => {
        try {
          console.log("WebSocket verifyClient called");
          console.log("Headers:", info.req.headers);
          console.log("Cookie header:", info.req.headers.cookie);

          // Log cookie information
          const cookies = parse(info.req.headers.cookie || "");
          console.log("Parsed cookies:", cookies);
          console.log("Session cookie:", cookies["mafia.sid"]);

          // Parse session using Promise wrapper
          await parseSession(info.req);

          // Log session data
          console.log("Session data:", (info.req as any).session);

          // Check if user is authenticated
          if (!(info.req as any).session?.passport?.user) {
            console.log("WebSocket connection rejected: Not authenticated");
            cb(false, 401, "Unauthorized");
            return;
          }

          cb(true);
        } catch (error) {
          console.error("WebSocket authentication error:", error);
          cb(false, 500, "Internal Server Error");
        }
      }
    });
    console.log("WebSocket server is setup on /game-ws path");

    wss.on("connection", async (ws: WebSocket, req) => {
      try {
        console.log("WebSocket connection established");
        console.log("Connected clients before:", this.connectedClients.size);
        console.log("Request headers:", req.headers);
        console.log("Cookie header:", req.headers.cookie);

        this.connectedClients.add(ws);
        console.log("Client connected, total clients:", this.connectedClients.size);

        const currentGame = this.games.get("default");
        if (currentGame) {
          ws.send(JSON.stringify(currentGame));
          console.log("Sent initial game state to client");
        }

        ws.on("message", (data: string) => {
          try {
            const message = JSON.parse(data.toString()) as GameMessage;
            console.log("Received message:", message);
            this.handleMessage(message, ws);
          } catch (err) {
            console.error("Failed to parse message:", err);
            ws.send(JSON.stringify({ 
              type: "error", 
              message: "Invalid message format" 
            }));
          }
        });

        ws.on("close", () => {
          console.log("WebSocket connection closed");
          this.connectedClients.delete(ws);
          console.log("Client disconnected, remaining clients:", this.connectedClients.size);
        });

        ws.on("error", (error) => {
          console.error("WebSocket error:", error);
          this.connectedClients.delete(ws);
        });

      } catch (error) {
        console.error("Error in WebSocket connection:", error);
        ws.close(1011, "Internal server error");
      }
    });
  }

  private async distributeRewards(game: GameState) {
    try {
      // Distribute rewards based on game outcome
      for (const player of game.players) {
        let reward = this.GAME_REWARDS.PARTICIPATION;

        // Additional rewards for survivors
        if (player.isAlive) {
          reward += this.GAME_REWARDS.SURVIVE;
        }

        // Additional rewards for winners
        if (game.winners?.includes(player.role!)) {
          reward += this.GAME_REWARDS.WIN;
        }

        // Update player's coins in storage
        await storage.updateUserCoins(player.id, reward);

        // Announce rewards
        this.broadcastSystemMessage(game, 
          `${player.username} earned ${reward} coins!`
        );
      }
    } catch (error) {
      console.error("Error distributing rewards:", error);
    }
  }

  private broadcastMessage(gameState: GameState) {
    const message = JSON.stringify(gameState);
    console.log("Broadcasting state to", this.connectedClients.size, "clients");
    this.connectedClients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(message);
      }
    });
  }

  private assignRoles(players: GameState["players"]): GameRole[] {
    const totalPlayers = players.length;
    const roles: GameRole[] = [];

    // Base roles
    roles.push("mafia", "doctor", "detective");
    if (totalPlayers >= 8) roles.push("don");
    if (totalPlayers >= 10) roles.push("sniper");
    if (totalPlayers >= 12) roles.push("spy");

    // Fill remaining slots with civilians
    while (roles.length < totalPlayers) {
      roles.push("civilian");
    }

    // Shuffle roles
    for (let i = roles.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [roles[i], roles[j]] = [roles[j], roles[i]];
    }

    return roles;
  }

  private startGame(game: GameState) {
    if (game.players.length < this.MIN_PLAYERS) {
      this.broadcastSystemMessage(game, "Need at least " + this.MIN_PLAYERS + " players to start");
      return;
    }

    const roles = this.assignRoles(game.players);
    game.players = game.players.map((player, index) => ({
      ...player,
      role: roles[index],
      isAlive: true,
      lastAction: undefined
    }));

    game.phase = "night";
    game.round = 1;
    game.actions = [];

    this.broadcastSystemMessage(game, "Game has started! Check your role.");
    this.broadcastMessage(game);
    this.startNightPhase(game);
  }

  private startNightPhase(game: GameState) {
    game.phase = "night";
    this.broadcastSystemMessage(game, "Night phase has started. Special roles can perform their actions.");
    this.broadcastMessage(game);

    setTimeout(() => {
      if (game.phase === "night") {
        this.startDayPhase(game);
      }
    }, this.NIGHT_DURATION);
  }

  private startDayPhase(game: GameState) {
    game.phase = "day";
    this.processNightActions(game);
    this.broadcastSystemMessage(game, "Day phase has started. Discuss and find the mafia!");
    this.broadcastMessage(game);

    setTimeout(() => {
      if (game.phase === "day") {
        this.startVotingPhase(game);
      }
    }, this.DAY_DURATION);
  }

  private startVotingPhase(game: GameState) {
    game.phase = "voting";
    this.broadcastSystemMessage(game, "Voting phase has started. Vote for a player to eliminate!");
    this.broadcastMessage(game);

    setTimeout(() => {
      if (game.phase === "voting") {
        this.processVotes(game);
        if (this.checkGameEnd(game)) {
          this.endGame(game);
        } else {
          game.round++;
          this.startNightPhase(game);
        }
      }
    }, this.VOTING_DURATION);
  }

  private broadcastSystemMessage(game: GameState, content: string) {
    game.messages.push({
      id: randomUUID(),
      username: "System",
      content,
      timestamp: Date.now(),
      isSystem: true
    });
    this.broadcastMessage(game);
  }

  private processNightActions(game: GameState) {
    const protectedPlayers = new Set<number>();
    const killedPlayers = new Set<number>();

    // Process protections
    game.actions.forEach(action => {
      if (action.type === "heal" || action.type === "protect") {
        protectedPlayers.add(action.toPlayer);
      }
    });

    // Process kills
    game.actions.forEach(action => {
      if (action.type === "kill" && !protectedPlayers.has(action.toPlayer)) {
        killedPlayers.add(action.toPlayer);
      }
    });

    // Update player states
    game.players = game.players.map(player => ({
      ...player,
      isAlive: player.isAlive && !killedPlayers.has(player.id)
    }));

    // Clear actions for next round
    game.actions = [];

    // Announce deaths
    killedPlayers.forEach(playerId => {
      const player = game.players.find(p => p.id === playerId);
      if (player) {
        this.broadcastSystemMessage(game, `${player.username} was killed during the night!`);
      }
    });
  }

  private processVotes(game: GameState) {
    const votes = new Map<number, number>();

    game.actions.forEach(action => {
      if (action.type === "vote") {
        votes.set(action.toPlayer, (votes.get(action.toPlayer) || 0) + 1);
      }
    });

    if (votes.size > 0) {
      let maxVotes = 0;
      let eliminatedPlayer: number | null = null;

      votes.forEach((count, playerId) => {
        if (count > maxVotes) {
          maxVotes = count;
          eliminatedPlayer = playerId;
        }
      });

      if (eliminatedPlayer) {
        const player = game.players.find(p => p.id === eliminatedPlayer);
        if (player) {
          player.isAlive = false;
          this.broadcastSystemMessage(game, `${player.username} was eliminated by vote!`);
        }
      }
    }

    game.actions = [];
  }

  private checkGameEnd(game: GameState): boolean {
    const alivePlayers = game.players.filter(p => p.isAlive);
    const mafiaCount = alivePlayers.filter(p => p.role === "mafia" || p.role === "don").length;
    const civilianCount = alivePlayers.length - mafiaCount;

    if (mafiaCount === 0) {
      game.winners = ["civilian", "doctor", "detective", "sniper", "spy"];
      return true;
    }

    if (mafiaCount >= civilianCount) {
      game.winners = ["mafia", "don"];
      return true;
    }

    return false;
  }

  private async endGame(game: GameState) {
    game.phase = "ended";
    const winnerRoles = game.winners?.join(", ") || "No one";
    this.broadcastSystemMessage(game, `Game Over! Winners: ${winnerRoles}`);

    // Distribute rewards
    await this.distributeRewards(game);

    this.broadcastMessage(game);

    // Reset game after delay
    setTimeout(() => {
      const newGame: GameState = {
        id: "default",
        players: [],
        phase: "waiting",
        round: 0,
        messages: [],
        actions: []
      };
      this.games.set("default", newGame);
      this.broadcastMessage(newGame);
    }, 10000);
  }

  private handleMessage(message: GameMessage, ws: WebSocket) {
    try {
      let currentGame = this.games.get("default");
      if (!currentGame) {
        currentGame = {
          id: "default",
          players: [],
          phase: "waiting",
          round: 0,
          messages: [],
          actions: []
        };
        this.games.set("default", currentGame);
      }

      switch (message.type) {
        case "chat":
          currentGame.messages.push({
            id: randomUUID(),
            username: message.username,
            content: message.content!,
            timestamp: Date.now()
          });
          this.broadcastMessage(currentGame);
          break;

        case "join":
          if (!currentGame.players.some(p => p.username === message.username)) {
            currentGame.players.push({
              id: currentGame.players.length + 1,
              username: message.username,
              isAlive: true
            });
            this.broadcastSystemMessage(currentGame, `${message.username} joined the game`);
            this.broadcastMessage(currentGame);

            // Auto-start game if enough players
            if (currentGame.phase === "waiting" && currentGame.players.length >= this.MIN_PLAYERS) {
              this.startGame(currentGame);
            }
          }
          break;

        case "ready":
          if (currentGame.phase === "waiting" && currentGame.players.length >= this.MIN_PLAYERS) {
            this.startGame(currentGame);
          }
          break;

        case "action":
          if (message.actionType && message.target !== undefined) {
            const player = currentGame.players.find(p => p.username === message.username);
            if (player && player.isAlive) {
              currentGame.actions.push({
                type: message.actionType,
                fromPlayer: player.id,
                toPlayer: message.target,
                timestamp: Date.now()
              });
            }
          }
          break;

        case "vote":
          if (currentGame.phase === "voting" && message.target !== undefined) {
            const player = currentGame.players.find(p => p.username === message.username);
            if (player && player.isAlive) {
              currentGame.actions.push({
                type: "vote",
                fromPlayer: player.id,
                toPlayer: message.target,
                timestamp: Date.now()
              });
            }
          }
          break;

        default:
          ws.send(JSON.stringify({
            type: "error",
            message: "Unknown message type"
          }));
      }
    } catch (error) {
      console.error("Error handling message:", error);
      ws.send(JSON.stringify({
        type: "error",
        message: "Failed to process message"
      }));
    }
  }
}