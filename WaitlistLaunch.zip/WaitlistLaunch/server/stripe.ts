import Stripe from "stripe";
import { storage } from "./storage";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: "2023-10-16",
});

const COIN_PRICES = {
  100: 1000,   // 100 coin = $10.00
  500: 4500,   // 500 coin = $45.00
  1000: 8000,  // 1000 coin = $80.00
};

export async function createPaymentIntent(userId: number, coins: number) {
  const amount = COIN_PRICES[coins as keyof typeof COIN_PRICES];
  if (!amount) {
    throw new Error("Invalid coin amount");
  }

  const paymentIntent = await stripe.paymentIntents.create({
    amount,
    currency: "usd",
    metadata: {
      userId,
      coins,
    },
  });

  return paymentIntent.client_secret;
}

export async function handleStripeWebhook(event: Stripe.Event) {
  switch (event.type) {
    case "payment_intent.succeeded": {
      const paymentIntent = event.data.object as Stripe.PaymentIntent;
      const { userId, coins } = paymentIntent.metadata;

      // Add coins to user's balance
      await storage.updateUserCoins(Number(userId), Number(coins));
      break;
    }
    case "payment_intent.payment_failed": {
      const paymentIntent = event.data.object as Stripe.PaymentIntent;
      console.error("Payment failed:", paymentIntent.id);
      break;
    }
  }
}
